from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.sentiments, name='index'),
    url(r'browse/', views.browse, name='browse'),
    url(r'^(?P<category>[a-z]+)/$', views.getComments, name='comments'),
]
