
from __future__ import unicode_literals
from django.db import models


class Album(models.Model):
    artist = models.CharField(max_length=200)
    artist_name = models.CharField(max_length=150, null=True)
    def __str__(self):
        return self.artist + ' : ' + self.artist_name


class CustomerComments(models.Model):
    positive = models.FloatField()
    negative = models.FloatField()

