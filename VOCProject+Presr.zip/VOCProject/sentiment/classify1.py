import nltk
import random
from nltk.corpus import movie_reviews
from nltk.classify.scikitlearn import SklearnClassifier
import pickle
from statistics import StatisticsError
from xlrd import open_workbook
from Comments import Comment

from sklearn.naive_bayes import MultinomialNB, BernoulliNB
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.svm import SVC, LinearSVC, NuSVC
from nltk.corpus import stopwords

from nltk.classify import ClassifierI
from statistics import mode

from nltk.tokenize import word_tokenize


def find_features(document, word_features):
    words = word_tokenize(document)
    features = {}
    for w in word_features:
        features[w] = (w in words)

    return features

class VoteClassifier(ClassifierI):
    def __init__(self, *classifiers):
        self._classifiers = classifiers

    def classify_from_sentence(self, sentence):
        votes = []
        for c in self._classifiers:
            v = c.classify(sentence)
            votes.append(v)
        print votes

    def classify(self, features):
        votes = []
        result = ""
        for c in self._classifiers:
            v = c.classify(features)
            votes.append(v)
        try:
            result = mode(votes)
        except StatisticsError:
            pass
        print features
        print votes
        return result

    def confidence(self, features):
        votes = []
        for c in self._classifiers:
            v = c.classify(features)
            votes.append(v)

        choice_votes = votes.count(mode(votes))
        conf = float(choice_votes) / len(votes)
        return conf

def classify():

    short_website = open("C:\\Users\\pgssolcenter\\Desktop\\VOC\\VOCProject\\sentiment\\training data\\Website.txt", "r").read()
    short_account = open("C:\\Users\\pgssolcenter\\Desktop\\VOC\\VOCProject\\sentiment\\training data\\Account related.txt", "r").read()
    short_navigation = open("C:\\Users\\pgssolcenter\\Desktop\\VOC\\VOCProject\\sentiment\\training data\\Navigation.txt", "r").read()
    short_payment = open("C:\\Users\\pgssolcenter\\Desktop\\VOC\\VOCProject\\sentiment\\training data\\payment.txt", "r").read()
    short_login = open("C:\\Users\\pgssolcenter\\Desktop\\VOC\\VOCProject\\sentiment\\training data\\Difficult to login.txt", "r").read()
    short_unknown = open("C:\\Users\\pgssolcenter\\Desktop\\VOC\\VOCProject\\sentiment\\training data\\others.txt", "r").read()
    short_product = open("C:\\Users\\pgssolcenter\\Desktop\\VOC\\VOCProject\\sentiment\\training data\\productRelated.txt", "r").read()
    short_customer = open("C:\\Users\\pgssolcenter\\Desktop\\VOC\\VOCProject\\sentiment\\training data\\Customer Service.txt", "r").read()
    short_competitor = open("C:\\Users\\pgssolcenter\\Desktop\\VOC\\VOCProject\\sentiment\\training data\\Competitor mentioned.txt", "r").read()
    short_information = open("C:\\Users\\pgssolcenter\\Desktop\\VOC\\VOCProject\\sentiment\\training data\\Difficult to find information.txt", "r").read()

    documents = []

    for r in short_website.split('\n'):
        documents.append((r, "website"))

    for r in short_account.split('\n'):
        documents.append((r, "account"))

    for r in short_navigation.split('\n'):
        documents.append((r, "navigation"))

    for r in short_login.split('\n'):
        documents.append((r, "login"))

    for r in short_product.split('\n'):
        documents.append((r, "product"))

    for r in short_unknown.split('\n'):
        documents.append((r, "others"))

    for r in short_payment.split('\n'):
        documents.append((r, "payment"))

    for r in short_customer.split('\n'):
        documents.append((r, "customer"))

    for r in short_competitor.split('\n'):
        documents.append((r, "competitor"))

    for r in short_information.split('\n'):
        documents.append((r, "information"))


    all_words = []

    short_website_words = word_tokenize(short_website)
    short_account_words = word_tokenize(short_account)
    short_navigation_words = word_tokenize(short_navigation)
    short_login_words = word_tokenize(short_login)
    short_product_words = word_tokenize(short_product)
    short_unknown_words = word_tokenize(short_unknown)
    short_payment_words = word_tokenize(short_payment)
    short_customer_words = word_tokenize(short_customer)
    short_competitor_words = word_tokenize(short_competitor)
    short_information_words = word_tokenize(short_information)


    final_short_website_words = []
    final_short_account_words = []
    final_short_navigation_words = []
    final_short_login_words = []
    final_short_product_words = []
    final_short_unknown_words = []
    final_short_customer_words = []
    final_short_payment_words = []
    final_short_competitor_words = []
    final_short_information_words = []

    stop_words = set(stopwords.words("english"))
    for sws in short_website_words:
        if sws not in stop_words:
            final_short_website_words.append(sws)

    for sws in short_account_words:
        if sws not in stop_words:
            final_short_account_words.append(sws)

    for sws in short_navigation_words:
        if sws not in stop_words:
            final_short_navigation_words.append(sws)

    for sws in short_login_words:
        if sws not in stop_words:
            final_short_login_words.append(sws)

    for sws in short_product_words:
        if sws not in stop_words:
            final_short_product_words.append(sws)

    for sws in short_unknown_words:
        if sws not in stop_words:
            final_short_unknown_words.append(sws)

    for sws in short_payment_words:
        if sws not in stop_words:
            final_short_payment_words.append(sws)

    for sws in short_competitor_words:
        if sws not in stop_words:
            final_short_competitor_words.append(sws)

    for sws in short_information_words:
        if sws not in stop_words:
            final_short_information_words.append(sws)


    for w in final_short_website_words:
        all_words.append(w.lower())

    for w in final_short_account_words:
        all_words.append(w.lower())

    for w in final_short_navigation_words:
        all_words.append(w.lower())

    for w in final_short_login_words:
        all_words.append(w.lower())

    for w in final_short_product_words:
        all_words.append(w.lower())

    for w in final_short_unknown_words:
        all_words.append(w.lower())

    for w in final_short_payment_words:
        all_words.append(w.lower())

    for w in final_short_competitor_words:
        all_words.append(w.lower())

    for w in final_short_information_words:
        all_words.append(w.lower())

    all_words = nltk.FreqDist(all_words)

    word_features = list(all_words.keys())[:5000]


    featuresets = [(find_features(rev, word_features), category) for (rev, category) in documents]

    random.shuffle(featuresets)


    training_set = featuresets

    classifier = nltk.NaiveBayesClassifier.train(training_set)
    workbook = open_workbook("C:\\Users\\pgssolcenter\\Desktop\\demo\\voc.xlsx")
    sheets = workbook.sheet_names()

    comments = []

    website = 0
    login = 0
    account = 0
    product = 0
    navigation = 0
    others = 0
    payment = 0
    customer = 0
    competitor = 0
    information = 0

    for sheet_name in sheets:
        sh = workbook.sheet_by_name(sheet_name)
        for rownum in range(sh.nrows):
            if rownum == 0:
                continue
            row_valaues = sh.row_values(rownum)
            for row_number in [6, 7, 8]:
                comment = Comment("", [], "")
                test_data = row_valaues[row_number]
                if test_data != '':
                    test_data_features = {word.lower(): (word in word_tokenize(test_data.lower())) for word in word_features}
                    comment.comment = test_data

                    categarory = classifier.classify(test_data_features)
                    print categarory
                    if categarory == "website":
                        comment.categories = ["website"]
                        website = website + 1

                    if categarory == "login":
                        comment.categories = ["login"]
                        login = login + 1

                    if categarory == "account":
                        comment.categories = ["account"]
                        account = account + 1

                    if categarory == "navigation":
                        comment.categories = ["navigation"]
                        navigation = navigation + 1

                    if categarory == "product":
                        comment.categories = ["product"]
                        product = product + 1

                    if categarory == "payment":
                        comment.categories = ["payment"]
                        payment = payment + 1

                    if categarory == "others":
                        comment.categories = ["others"]
                        others = others + 1

                    if categarory == "customer":
                        comment.categories = ["customer"]
                        customer = customer + 1

                    if categarory == "competitor":
                        comment.categories = ["competitor"]
                        competitor = competitor + 1

                    if categarory == "information":
                        comment.categories = ["information"]
                        information = information + 1

                    comments.append(comment)
            #

            # MNB_classifier = SklearnClassifier(MultinomialNB())
            # MNB_classifier.train(training_set)


            # BernoulliNB_classifier = SklearnClassifier(BernoulliNB())
            # BernoulliNB_classifier.train(training_set)

            # LogisticRegression_classifier = SklearnClassifier(LogisticRegression())
            # LogisticRegression_classifier.train(training_set)


            # SGDClassifier_classifier = SklearnClassifier(SGDClassifier())
            # SGDClassifier_classifier.train(training_set)


            # LinearSVC_classifier = SklearnClassifier(LinearSVC())
            # LinearSVC_classifier.train(training_set)

            # voted_classifier = VoteClassifier(
            #     classifier,
            #     LinearSVC_classifier,
            #     MNB_classifier,
            #     BernoulliNB_classifier,
            #     LogisticRegression_classifier)
            #
            # print "Voted: " + voted_classifier.classify(test_data_features)
            #
            # categarory = voted_classifier.classify(test_data_features)
        print "website", website, "login", login, "account", account, "navigation", navigation, "product", product, "others", others, "payment", payment, "customer", customer, "competitor", competitor, "information", information

        return comments
