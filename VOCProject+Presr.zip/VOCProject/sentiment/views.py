from __future__ import unicode_literals
from django.http import HttpResponse
from django.template import loader
from .models import Album
from . import vader
from nltk.corpus import stopwords
from nltk import word_tokenize
import classify1
import write_to_excel
import subprocess
import psutil
import classification
import pickle
import operator

def index(request):

    albums = Album.objects.all()
    html = ''
    template = loader.get_template('sentiment/index.html')
    context = {
        'albums': albums,
    }
    return HttpResponse(template.render(context, request))

def browse(request):
    template = loader.get_template("sentiment/browse.html")
    return HttpResponse(template.render({}, request))

def getComments(request, category):
    comment_results = []
    try:
        with open("bin.dat") as f:
            comment_results = pickle.load(f)
    except:
        pass
    html = ''
    result = []
    for comment in comment_results:
        if category in comment.categories:
            result.append(comment)

    sorted_result = sorted(result, key=operator.attrgetter('sentiment'))
    for comment in sorted_result:
        html += comment.comment + '$#%^' + comment.sentiment + "||"

    return HttpResponse(html)

# def getSentiments():
#     comments_results = classify1.classify()
#     pos = neg = neu = webpos = webneg = webneu = logpos = logneg = logneu = accpos = accneg = accneu = navpos = navneg = navneu = custpos = custneg = custneu = paypos = payneg = payneu = unpos = unneg = unneu = 0
#     operators = ['and', 'or', 'not']
#     stop_words = set(stopwords.words("english")) - set(operators)
#     for specific_comment in comments_results:
#         test_data = specific_comment.comment
#         words = word_tokenize(test_data)
#         filtered_words_list = [w for w in words if not w in stop_words]
#         test_data = ' '.join(filtered_words_list)
#
#         ss = vader.getSentiment(test_data)
#         if ss['compound'] >= 0.1:
#             pos += 1
#             specific_comment.sentiment = "positive"
#            # print( " POS :::: " + "Pos : " + str(ss['pos']) + " Neg : " + str(ss['neg']) + " Neu : " + str(ss['neu']) + " Compound : " + str(ss['compound']))
#         elif ss['compound'] < 0:
#             neg += 1
#             specific_comment.sentiment = "negative"
#         else:
#             neu += 1
#             specific_comment.sentiment = "neutral"
#
#     for specific_comment in comments_results:
#         if "website" in specific_comment.categories:
#             if specific_comment.sentiment == "positive":
#                 webpos += 1
#             elif specific_comment.sentiment == "negative":
#                 webneg += 1
#             else:
#                 webneu += 1
#
#         if "login" in specific_comment.categories:
#             if specific_comment.sentiment == "positive":
#                 logpos += 1
#             elif specific_comment.sentiment == "negative":
#                 logneg += 1
#             else:
#                 logneu += 1
#         if "account" in specific_comment.categories:
#             if specific_comment.sentiment == "positive":
#                 accpos += 1
#             elif specific_comment.sentiment == "Negative":
#                 accneg += 1
#             else:
#                 accneu += 1
#         if "navigation" in specific_comment.categories:
#             if specific_comment.sentiment == "positive":
#                 navpos += 1
#             elif specific_comment.sentiment == "negative":
#                 navneg += 1
#             else:
#                 navneu += 1
#         if "customer" in specific_comment.categories:
#             if specific_comment.sentiment == "positive":
#                 custpos += 1
#             elif specific_comment.sentiment == "negative":
#                 custneg += 1
#             else:
#                 custneu += 1
#         if "payment" in specific_comment.categories:
#             if specific_comment.sentiment == "positive":
#                 paypos += 1
#             elif specific_comment.sentiment == "negative":
#                 payneg += 1
#             else:
#                 payneu += 1
#         if "uncategorised" in specific_comment.categories:
#             if specific_comment.sentiment == "positive":
#                 unpos += 1
#             elif specific_comment.sentiment == "negative":
#                 unneg += 1
#             else:
#                 unneu += 1
#
#
#
#     return comments_results
#


def sentiments(request):
    comments_results = classify1.classify()
    pos = neg = neu = webpos = webneg = webneu = logpos = logneg = logneu = accpos = accneg = accneu = navpos = navneg = navneu = custpos = custneg = custneu = paypos = payneg = payneu = unpos = unneg = unneu = 0
    operators = ['and', 'or', 'not']
    stop_words = set(stopwords.words("english")) - set(operators)
    for specific_comment in comments_results:
        test_data = specific_comment.comment
        words = word_tokenize(test_data)
        filtered_words_list = [w for w in words if not w in stop_words]
        test_data = ' '.join(filtered_words_list)

        ss = vader.getSentiment(test_data)
        if ss['compound'] >= 0.1:
            pos += 1
            specific_comment.sentiment = "positive"
           # print( " POS :::: " + "Pos : " + str(ss['pos']) + " Neg : " + str(ss['neg']) + " Neu : " + str(ss['neu']) + " Compound : " + str(ss['compound']))
        elif ss['compound'] < 0:
            neg += 1
            specific_comment.sentiment = "negative"
        else:
            neu += 1
            specific_comment.sentiment = "neutral"

    for specific_comment in comments_results:
        if "website" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                webpos += 1
            elif specific_comment.sentiment == "negative":
                webneg += 1
            else:
                webneu += 1

        if "login" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                logpos += 1
            elif specific_comment.sentiment == "negative":
                logneg += 1
            else:
                logneu += 1
        if "account" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                accpos += 1
            elif specific_comment.sentiment == "negative":
                accneg += 1
            else:
                accneu += 1
        if "navigation" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                navpos += 1
            elif specific_comment.sentiment == "negative":
                navneg += 1
            else:
                navneu += 1
        if "customer" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                custpos += 1
            elif specific_comment.sentiment == "negative":
                custneg += 1
            else:
                custneu += 1
        if "product" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                paypos += 1
            elif specific_comment.sentiment == "negative":
                payneg += 1
            else:
                payneu += 1
        if "information" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                unpos += 1
            elif specific_comment.sentiment == "negative":
                unneg += 1
            else:
                unneu += 1
    cats = ["Website", "Account", "Navigation", "Login", "Others", "Payment", "Customer"]
    vals_pos = [webpos, accpos, navpos, logpos, unpos, paypos, custpos]
    vals_negs = [webneg, accneg, navneg, logneg, unneg, payneg, custneg]
    most_pos = cats[vals_pos.index(max(vals_pos))]
    most_neg = cats[vals_negs.index(max(vals_negs))]
    most_pos_val = max(vals_pos)
    most_neg_val = max(vals_negs)
    context = {
        'website' : {
            'pos': webpos,
            'neg': webneg,
            'neu': webneu,
        },
        'login': {
            'pos': logpos,
            'neg': logneg,
            'neu': logneu,
        },
        'account': {
            'pos': accpos,
            'neg': accneg,
            'neu': accneu,
        },
        'navigation': {
            'pos': navpos,
            'neg': navneg,
            'neu': navneu,
        },
        'customer': {
            'pos': custpos,
            'neg': custneg,
            'neu': custneu,
        },
        'product': {
            'pos': paypos,
            'neg': payneg,
            'neu': payneu,
        },
        'information': {
            'pos': unpos,
            'neg': unneg,
            'neu': unneu,
        },
        'total': {
            'pos': pos,
            'neg': neg,
            'neu': neu,
            'total': pos+neg+neu,
            'most_pos_val':most_pos_val,
            'most_neg_val': most_neg_val,
            'most_pos': most_pos,
            'most_neg': most_neg,
        },
    }
    with open("bin.dat", "wb") as f:
        pickle.dump(comments_results, f)

    filepath = "C:/Users/pgssolcenter/Desktop/asd.bat"
    PROCNAME = "tableau.exe"
    for proc in psutil.process_iter():
        if proc.name() == PROCNAME:
            print(proc)
    p = subprocess.Popen(filepath, shell=True, stdout= subprocess.PIPE)
    write_to_excel.createExcelForTableau(comments_results)
    template = loader.get_template('sentiment/chartjs.html')
    return HttpResponse(template.render(context, request))
