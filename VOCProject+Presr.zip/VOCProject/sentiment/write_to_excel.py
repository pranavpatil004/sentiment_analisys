import xlwt
from xlrd import open_workbook
from .Comments import Comment
import os
import os.path


def createExcelForTableau(comment_list):
    if os.path.exists("C:\Users\pgssolcenter\AppData\Local\Temp\TableauTemp\1716798453\Data\Datasources\Tableuo.xls"):
        os.remove("C:\Users\pgssolcenter\AppData\Local\Temp\TableauTemp\1716798453\Data\Datasources\Tableuo.xls")
    print("File Removed!")
    bk = xlwt.Workbook()
    sheet = bk.add_sheet("data for tableau")

    sheet.write(0, 0, "Comment")
    sheet.write(0, 1, "Sentiment")
    sheet.write(0, 2, "Website related")
    sheet.write(0, 3, "Difficult to login")
    sheet.write(0, 4, "Product related")
    sheet.write(0, 5, "Customer service")
    sheet.write(0, 6, "Account related")
    sheet.write(0, 7, "Navigation")
    sheet.write(0, 8, "Competitor mentioned")
    sheet.write(0, 9, "Payment relayed")
    sheet.write(0, 10, "Difficult to find information")
    sheet.write(0, 11, "Others")

    for index, Comment in enumerate(comment_list):
        print index, Comment
        sheet.write(index + 1, 0, Comment.comment)
        sheet.write(index + 1, 1, Comment.sentiment)

        if "website" in Comment.categories:
            sheet.write(index + 1, 2, 1)

        if "login" in Comment.categories:
            sheet.write(index + 1, 3, 1)

        if "product" in Comment.categories:
            sheet.write(index + 1, 4, 1)

        if "customer" in Comment.categories:
            sheet.write(index + 1, 5, 1)

        if "account" in Comment.categories:
            sheet.write(index + 1, 6, 1)

        if "navigation" in Comment.categories:
            sheet.write(index + 1, 7, 1)

        if "competitor" in Comment.categories:
            sheet.write(index + 1, 8, 1)

        if "payment" in Comment.categories:
            sheet.write(index + 1, 9, 1)

        if "information" in Comment.categories:
            sheet.write(index + 1, 10, 1)

        if "others" in Comment.categories:
            sheet.write(index + 1, 11, 1)

    bk.save("Tableuo.xls")