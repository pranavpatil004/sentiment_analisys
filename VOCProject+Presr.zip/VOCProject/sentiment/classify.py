import nltk
import random
from nltk.corpus import movie_reviews
from nltk.classify.scikitlearn import SklearnClassifier
import pickle
from statistics import StatisticsError
from xlrd import open_workbook

from sklearn.naive_bayes import MultinomialNB, BernoulliNB
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.svm import SVC, LinearSVC, NuSVC
from nltk.corpus import stopwords

from nltk.classify import ClassifierI
from statistics import mode

from nltk.tokenize import word_tokenize


class VoteClassifier(ClassifierI):
    def __init__(self, *classifiers):
        self._classifiers = classifiers

    def classify_from_sentence(self, sentence):
        votes = []
        for c in self._classifiers:
            v = c.classify(sentence)
            votes.append(v)
        print votes
    def classify(self, features):
        votes = []
        result = ""
        for c in self._classifiers:
            v = c.classify(features)
            votes.append(v)
        try:
            result = mode(votes)
        except StatisticsError:
            pass
        print features
        print votes
        return result

    def confidence(self, features):
        votes = []
        for c in self._classifiers:
            v = c.classify(features)
            votes.append(v)

        choice_votes = votes.count(mode(votes))
        conf = float(choice_votes) / len(votes)
        return conf


short_website = open("short_review/website.txt", "r").read()
short_account = open("short_review/account.txt", "r").read()
short_navigation = open("short_review/navigation.txt", "r").read()
short_login= open("short_review/payment.txt", "r").read()
short_product = open("short_review/product.txt", "r").read()
short_unknown = open("short_review/others.txt", "r").read()
# short_product = open("short_reviews/product.txt", "r").read()
# short_customer = open("short_reviews/customer.txt", "r").read()


documents = []

for r in short_website.split('\n'):
    documents.append((r, "website"))

for r in short_account.split('\n'):
    documents.append((r, "account"))

for r in short_navigation.split('\n'):
    documents.append((r, "navigation"))

for r in short_login.split('\n'):
    documents.append((r, "login"))

for r in short_product.split('\n'):
    documents.append((r, "product"))

for r in short_unknown.split('\n'):
    documents.append((r, "others"))

# for r in short_product.split('\n'):
#     documents.append((r, "product"))
#
# for r in short_customer.split('\n'):
#     documents.append((r, "customer"))




all_words = []

short_website_words = word_tokenize(short_website)
short_account_words = word_tokenize(short_account)
short_navigation_words = word_tokenize(short_navigation)
short_login_words = word_tokenize(short_login)
short_product_words = word_tokenize(short_product)
short_unknown_words = word_tokenize(short_unknown)
# short_product_words = word_tokenize(short_product)
# short_customer_words = word_tokenize(short_product)


final_short_website_words = []
final_short_account_words = []
final_short_navigation_words = []
final_short_login_words = []
final_short_product_words = []
final_short_unknown_words = []
final_short_customer_words = []


stop_words = set(stopwords.words("english"))
for sws in short_website_words:
    if sws not in stop_words:
        final_short_website_words.append(sws)

for sws in short_account_words:
    if sws not in stop_words:
        final_short_account_words.append(sws)

for sws in short_navigation_words:
    if sws not in stop_words:
        final_short_navigation_words.append(sws)

for sws in short_login_words:
    if sws not in stop_words:
        final_short_login_words.append(sws)

for sws in short_product_words:
    if sws not in stop_words:
        final_short_product_words.append(sws)

for sws in short_unknown_words:
    if sws not in stop_words:
        final_short_unknown_words.append(sws)




for w in final_short_website_words:
    all_words.append(w.lower())

for w in final_short_account_words:
    all_words.append(w.lower())

for w in final_short_navigation_words:
    all_words.append(w.lower())

for w in final_short_login_words:
    all_words.append(w.lower())

for w in final_short_product_words:
    all_words.append(w.lower())

for w in final_short_unknown_words:
    all_words.append(w.lower())

all_words = nltk.FreqDist(all_words)

word_features = list(all_words.keys())[:5000]


def find_features(document):
    words = word_tokenize(document)
    features = {}
    for w in word_features:
        features[w] = (w in words)

    return features


# print((find_features(movie_reviews.words('neg/cv000_29416.txt'))))

featuresets = [(find_features(rev), category) for (rev, category) in documents]

random.shuffle(featuresets)

# positive data example:
training_set = featuresets
#testing_set = featuresets

workbook = open_workbook("C:\\Users\\pgssolcenter\\Desktop\\voc.xlsx")
sheets = workbook.sheet_names()


#categaroy_list = ["website","login","customer","navigation","account"]

website = 0
login = 0
account = 0
product = 0
navigation = 0
others = 0



for sheet_name in sheets:
        sh = workbook.sheet_by_name(sheet_name)
        for rownum in range(sh.nrows):
            if rownum == 0:
                continue
           # comment = Comment("", [], "")
            row_valaues = sh.row_values(rownum)
            test_data = row_valaues[8]
            test_data_features = {word.lower(): (word in word_tokenize(test_data.lower())) for word in word_features}
##
### negative data example:
##training_set = featuresets[100:]
##testing_set =  featuresets[:100]


            classifier = nltk.NaiveBayesClassifier.train(training_set)
            print "Neaive Bays: " + classifier.classify(test_data_features)
           # print("Original Naive Bayes Algo accuracy percent:", (nltk.classify.accuracy(classifier, test_data_features)) * 100)

            MNB_classifier = SklearnClassifier(MultinomialNB())
            MNB_classifier.train(training_set)
            print "MNB: " + MNB_classifier.classify(test_data_features)
            # print("MNB_classifier accuracy percent:", (nltk.classify.accuracy(MNB_classifier, test_data_features)) * 100)

            BernoulliNB_classifier = SklearnClassifier(BernoulliNB())
            BernoulliNB_classifier.train(training_set)
            print "Bernoulli:" + BernoulliNB_classifier.classify(test_data_features)
            # print("BernoulliNB_classifier accuracy percent:", (nltk.classify.accuracy(BernoulliNB_classifier, test_data_features)) * 100)

            LogisticRegression_classifier = SklearnClassifier(LogisticRegression())
            LogisticRegression_classifier.train(training_set)
            print "Logistic : " + LogisticRegression_classifier.classify(test_data_features)
            # print("LogisticRegression_classifier accuracy percent:",(nltk.classify.accuracy(LogisticRegression_classifier, test_data)) * 100)

            SGDClassifier_classifier = SklearnClassifier(SGDClassifier())
            SGDClassifier_classifier.train(training_set)
            print "SGDClassifier : " + SGDClassifier_classifier.classify(test_data_features)
            # print("SGDClassifier_classifier accuracy percent:", (nltk.classify.accuracy(SGDClassifier_classifier, test_data_features)) * 100)

            ##SVC_classifier = SklearnClassifier(SVC())
            ##SVC_classifier.train(training_set)
            ##print("SVC_classifier accuracy percent:", (nltk.classify.accuracy(SVC_classifier, testing_set))*100)

            LinearSVC_classifier = SklearnClassifier(LinearSVC())
            LinearSVC_classifier.train(training_set)
            print "LinearSVC : " + LinearSVC_classifier.classify(test_data_features)
            # print("LinearSVC_classifier accuracy percent:", (nltk.classify.accuracy(LinearSVC_classifier, test_data_features)) * 100)

            # NuSVC_classifier = SklearnClassifier(NuSVC())
            # NuSVC_classifier.train(training_set)
            # print("NuSVC_classifier accuracy percent:", (nltk.classify.accuracy(NuSVC_classifier, testing_set)) * 100)

            voted_classifier = VoteClassifier(
                classifier,
                LinearSVC_classifier,
                MNB_classifier,
                BernoulliNB_classifier,
                LogisticRegression_classifier)

            print "Voted: " + voted_classifier.classify(test_data_features)

            categarory = voted_classifier.classify(test_data_features)

            if categarory == "website":
                # print (test_data_features)
                # print (classifier.classify(test_data_features))
                # comment.categories = ["website"]
                website = website + 1

            if categarory == "login":
                # print (test_data_features)
                # print (classifier.classify(test_data_features))
                login =  login + 1

            if categarory == "account":
                # print (test_data_features)
                # print (classifier.classify(test_data_features)
                account = account + 1

            if categarory == "navigation":
                # print (test_data_features)
                # print (classifier.classify(test_data_features))
                navigation = navigation + 1

            if categarory == "product":
                # print (test_data_features)
                # print (classifier.classify(test_data_features))
                product = product + 1

            if categarory == "others":
                # print (test_data_features)
                # print (classifier.classify(test_data_features))
                others = others + 1


                # print("voted_classifier accuracy percent:", (nltk.classify.accuracy(voted_classifier, test_data_features)) * 100)
print "website" , website , "login", login , "account" , account, "navigation", navigation ,"product" ,product, "others" ,others