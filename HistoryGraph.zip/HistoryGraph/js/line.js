$(document).ready(function() {

	//get canvas
	var ctx = $("#line-chartcanvas");

	var data = {
		labels : ["Q1-2017", "Q2-2017", "Q3-2017", "Q4-2017"],
		datasets : [
			{
				label : "Neutral",
				data : [10, 50, 25, 70],
				backgroundColor : "orange",
				borderColor : "orange",
				fill : false,
				lineTension : 0,
				pointRadius : 5
			},
			{
				label : "Positive",
				data : [20, 35, 40, 60],
				backgroundColor : "green",
				borderColor : "green",
				fill : false,
				lineTension : 0,
				pointRadius : 5
			},
			{
				label : "Negative",
				data : [10, 25, 30, 25],
				backgroundColor : "red",
				borderColor : "red",
				fill : false,
				lineTension : 0,
				pointRadius : 5
			}
		]
	};

	var options = {
		title : {
			display : true,
			position : "top",
			text : "Category - Website",
			fontSize : 18,
			fontColor : "#111"
		},
		legend : {
			display : true,
			position : "bottom"
		}
	};

	var chart = new Chart( ctx, {
		type : "line",
		data : data,
		options : options
	} );

});