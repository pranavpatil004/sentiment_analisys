from __future__ import unicode_literals
from django.http import HttpResponse
from django.template import loader
from django.shortcuts import render
from nltk.util import elementtree_indent
from .Comments import Comment
from .models import Album
from . import vader
import json
import xlwt
from nltk.corpus import stopwords
from nltk import word_tokenize
from xlrd import open_workbook
def index(request):
    albums = Album.objects.all()
    html = ''
    template = loader.get_template('sentiment/index.html')
    context = {
        'albums': albums,
    }
    return HttpResponse(template.render(context, request))



def sentiments(request):
    comments_results = []
    book = open_workbook('C:\\Users\\pgssolcenter\\Desktop\\voc.xlsx')
    sheets = book.sheet_names()[0]
    sh = book.sheet_by_name(sheets)
    context = {}
    pos = 0
    neg = 0
    neu = 0
    webpos = webneg = webneu = logpos = logneg = logneu = accpos = accneg = accneu = navpos = navneg = navneu = custpos = custneg = custneu = paypos = payneg = payneu = 0
    operators = ['and', 'or', 'not']
    stop_words = set(stopwords.words("english")) - set(operators)
    for rownum in range(sh.nrows):
        if rownum == 0:
            continue
        row_valaues = sh.row_values(rownum)
        test_data = row_valaues[8]
        words = word_tokenize(test_data)
        filtered_words_list = [w for w in words if not w in stop_words]
        test_data = ' '.join(filtered_words_list)

        ss = vader.getSentiment(test_data)
        if ss['compound'] >= 0.5:
            pos += 1
            comments_results.append(Comment(test_data, ["website"], "Positive"))
           # print( " POS :::: " + "Pos : " + str(ss['pos']) + " Neg : " + str(ss['neg']) + " Neu : " + str(ss['neu']) + " Compound : " + str(ss['compound']))
        elif ss['compound'] < 0:
            neg += 1
            comments_results.append(Comment(test_data, ["website"], "Negative"))

            #print( " NEG :::: " + "Pos : " + str(ss['pos']) + " Neg : " + str(ss['neg']) + " Neu : " + str(ss['neu']) + " Compound : " + str(ss['compound']))
        else:
            neu += 1
            comments_results.append(Comment(test_data, ["website"], "Neutral"))
            print(test_data);
            print( " NEU :::: " + "Pos : " + str(ss['pos']) + " Neg : " + str(ss['neg']) + " Neu : " + str(ss['neu']) + " Compound : " + str(ss['compound']))


    #
    # context = {
    #     'pos': pos,
    #     'neg': neg,
    #     'neu': neu,
    # }
    categories = ["website", "login", "account", "navigation", "customer", "payment"]
    for specific_comment in comments_results:
        if "website" in specific_comment.categories:
            if specific_comment.sentiment == "Positive":
                webpos += 1
            elif specific_comment.sentiment == "Negative":
                webneg += 1
            else:
                webneu += 1

        if "login" in specific_comment.categories:
            if specific_comment.sentiment == "Positive":
                logpos += 1
            elif specific_comment.sentiment == "Negative":
                logneg += 1
            else:
                logneu += 1
        if "account" in specific_comment.categories:
            if specific_comment.sentiment == "Positive":
                accpos += 1
            elif specific_comment.sentiment == "Negative":
                accneg += 1
            else:
                accneu += 1
        if "navigation" in specific_comment.categories:
            if specific_comment.sentiment == "Positive":
                navpos += 1
            elif specific_comment.sentiment == "Negative":
                navneg += 1
            else:
                navneu += 1
        if "customer" in specific_comment.categories:
            if specific_comment.sentiment == "Positive":
                custpos += 1
            elif specific_comment.sentiment == "Negative":
                custneg += 1
            else:
                custneu += 1
        if "payment" in specific_comment.categories:
            if specific_comment.sentiment == "Positive":
                paypos += 1
            elif specific_comment.sentiment == "Negative":
                payneg += 1
            else:
                payneu += 1


    context = {
        'website' : {
            'pos': webpos,
            'neg': webneg,
            'neu': webneu,
        },
        'login': {
            'pos': logpos,
            'neg': logneg,
            'neu': logneu,
        },
        'account': {
            'pos': accpos,
            'neg': accneg,
            'neu': accneu,
        },
        'navigation': {
            'pos': navpos,
            'neg': navneg,
            'neu': navneu,
        },
        'customer': {
            'pos': custpos,
            'neg': custneg,
            'neu': custneu,
        },
        'payment': {
            'pos': paypos,
            'neg': payneg,
            'neu': payneu,
        },
    }

    template = loader.get_template('sentiment/index.html')
    return HttpResponse(template.render(context, request))
