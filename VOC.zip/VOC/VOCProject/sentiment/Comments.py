

class Comment:
    def __init__(self, comment, categories, sentiment):
        self.comment = comment
        self.categories = categories
        self.sentiment = sentiment