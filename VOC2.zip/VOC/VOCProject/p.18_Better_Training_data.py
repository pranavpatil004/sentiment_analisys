from textblob.classifiers import NaiveBayesClassifier
import nltk
from xlrd import open_workbook
from nltk.tokenize import word_tokenize

with open("C:\\Users\\pgssolcenter\\Desktop\\website.csv") as fp:
    cl = NaiveBayesClassifier(fp, format="csv")

# print cl.classify("I got a message The System is currently unavailable.")

workbook = open_workbook("C:\\Users\\pgssolcenter\\Desktop\\voc.xlsx")
sheets = workbook.sheet_names()

required_data = []
for sheet_name in sheets:
    sh = workbook.sheet_by_name(sheet_name)
    for rownum in range(sh.nrows):
        if rownum == 0:
            continue
        row_valaues = sh.row_values(rownum)
        test_data = row_valaues[8]
        print test_data
        probabilities = cl.prob_classify(test_data)
        for sample in probabilities.samples():
            print "{0}: {1}".format(sample, probabilities.prob(sample))
        print "Classify: " + str(cl.classify(test_data))

# articles = [({'entertaining':0.6, 'informative':0.2, 'statistical':0.6}, 'sports'),
#             ({'entertaining':0.7, 'informative':0.2, 'statistical':0.8}, 'sports'),
#             ({'entertaining':0.1, 'informative':0.7, 'statistical':0.2}, 'news'),
#             ({'entertaining':0.2, 'informative':0.8, 'statistical':0.3}, 'news'),
#             ({'entertaining':0.8, 'informative':0.2, 'statistical':0.1}, 'movies')]
#
# classifier = nltk.NaiveBayesClassifier.train(articles)
#
# label = classifier.classify({'entertaining':0.9, 'informative':0.2, 'statistical':0.1})
#
# print label
# #movies
#
# probabilities = classifier.prob_classify({'entertaining':0.9, 'informative':0.2, 'statistical':0.1})
#
# for sample in probabilities.samples():
#     print "{0}: {1}".format(sample, probabilities.prob(sample))