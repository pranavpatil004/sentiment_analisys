from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.sentiments, name='index'),
    url(r'^(?P<category>[a-z]+)/(?P<sentiment>[a-z]+)/$', views.getComments, name='comments')
]
