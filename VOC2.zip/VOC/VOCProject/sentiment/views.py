from __future__ import unicode_literals
from django.http import HttpResponse
from django.template import loader
from .models import Album
from . import vader
from nltk.corpus import stopwords
from nltk import word_tokenize
import classification

def index(request):

    albums = Album.objects.all()
    html = ''
    template = loader.get_template('sentiment/index.html')
    context = {
        'albums': albums,
    }
    return HttpResponse(template.render(context, request))

def getComments(request, category, sentiment):
    comment_results = getSentiments()
    print category + sentiment + str(comment_results)
    html = ''
    result = []
    for comment in comment_results:
        if category in comment.categories:
            if sentiment == comment.sentiment:
                result.append(comment)

    for comment in result:
        html += comment.comment + '&nbsp' + comment.sentiment + '&nbsp' + str(comment.categories) + '<br/>'
    return HttpResponse(html)

def getSentiments():
    comments_results = classification.classify()
    pos = neg = neu = webpos = webneg = webneu = logpos = logneg = logneu = accpos = accneg = accneu = navpos = navneg = navneu = custpos = custneg = custneu = paypos = payneg = payneu = unpos = unneg = unneu = 0
    operators = ['and', 'or', 'not']
    stop_words = set(stopwords.words("english")) - set(operators)
    for specific_comment in comments_results:
        test_data = specific_comment.comment
        words = word_tokenize(test_data)
        filtered_words_list = [w for w in words if not w in stop_words]
        test_data = ' '.join(filtered_words_list)

        ss = vader.getSentiment(test_data)
        if ss['compound'] >= 0.5:
            pos += 1
            specific_comment.sentiment = "positive"
           # print( " POS :::: " + "Pos : " + str(ss['pos']) + " Neg : " + str(ss['neg']) + " Neu : " + str(ss['neu']) + " Compound : " + str(ss['compound']))
        elif ss['compound'] < 0:
            neg += 1
            specific_comment.sentiment = "negative"
        else:
            neu += 1
            specific_comment.sentiment = "neutral"

    for specific_comment in comments_results:
        if "website" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                webpos += 1
            elif specific_comment.sentiment == "negative":
                webneg += 1
            else:
                webneu += 1

        if "login" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                logpos += 1
            elif specific_comment.sentiment == "negative":
                logneg += 1
            else:
                logneu += 1
        if "account" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                accpos += 1
            elif specific_comment.sentiment == "Negative":
                accneg += 1
            else:
                accneu += 1
        if "navigation" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                navpos += 1
            elif specific_comment.sentiment == "negative":
                navneg += 1
            else:
                navneu += 1
        if "customer" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                custpos += 1
            elif specific_comment.sentiment == "negative":
                custneg += 1
            else:
                custneu += 1
        if "payment" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                paypos += 1
            elif specific_comment.sentiment == "negative":
                payneg += 1
            else:
                payneu += 1
        if "uncategorised" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                unpos += 1
            elif specific_comment.sentiment == "negative":
                unneg += 1
            else:
                unneu += 1



    return comments_results



def sentiments(request):
    comments_results = classification.classify()
    pos = neg = neu = webpos = webneg = webneu = logpos = logneg = logneu = accpos = accneg = accneu = navpos = navneg = navneu = custpos = custneg = custneu = paypos = payneg = payneu = unpos = unneg = unneu = 0
    operators = ['and', 'or', 'not']
    stop_words = set(stopwords.words("english")) - set(operators)
    for specific_comment in comments_results:
        test_data = specific_comment.comment
        words = word_tokenize(test_data)
        filtered_words_list = [w for w in words if not w in stop_words]
        test_data = ' '.join(filtered_words_list)

        ss = vader.getSentiment(test_data)
        if ss['compound'] >= 0.5:
            pos += 1
            specific_comment.sentiment = "positive"
           # print( " POS :::: " + "Pos : " + str(ss['pos']) + " Neg : " + str(ss['neg']) + " Neu : " + str(ss['neu']) + " Compound : " + str(ss['compound']))
        elif ss['compound'] < 0:
            neg += 1
            specific_comment.sentiment = "negative"
        else:
            neu += 1
            specific_comment.sentiment = "neutral"

    for specific_comment in comments_results:
        if "website" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                webpos += 1
            elif specific_comment.sentiment == "negative":
                webneg += 1
            else:
                webneu += 1

        if "login" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                logpos += 1
            elif specific_comment.sentiment == "negative":
                logneg += 1
            else:
                logneu += 1
        if "account" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                accpos += 1
            elif specific_comment.sentiment == "negative":
                accneg += 1
            else:
                accneu += 1
        if "navigation" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                navpos += 1
            elif specific_comment.sentiment == "negative":
                navneg += 1
            else:
                navneu += 1
        if "customer" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                custpos += 1
            elif specific_comment.sentiment == "negative":
                custneg += 1
            else:
                custneu += 1
        if "payment" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                paypos += 1
            elif specific_comment.sentiment == "negative":
                payneg += 1
            else:
                payneu += 1
        if "uncategorised" in specific_comment.categories:
            if specific_comment.sentiment == "positive":
                unpos += 1
            elif specific_comment.sentiment == "negative":
                unneg += 1
            else:
                unneu += 1


    context = {
        'website' : {
            'pos': webpos,
            'neg': webneg,
            'neu': webneu,
        },
        'login': {
            'pos': logpos,
            'neg': logneg,
            'neu': logneu,
        },
        'account': {
            'pos': accpos,
            'neg': accneg,
            'neu': accneu,
        },
        'navigation': {
            'pos': navpos,
            'neg': navneg,
            'neu': navneu,
        },
        'customer': {
            'pos': custpos,
            'neg': custneg,
            'neu': custneu,
        },
        'payment': {
            'pos': paypos,
            'neg': payneg,
            'neu': payneu,
        },
        'uncategorised': {
            'pos': unpos,
            'neg': unneg,
            'neu': unneu,
        },
        'total': {
            'pos': pos,
            'neg': neg,
            'neu': neu,
        }
    }

    template = loader.get_template('sentiment/index.html')
    return HttpResponse(template.render(context, request))
