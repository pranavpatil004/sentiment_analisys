import nltk
from xlrd import open_workbook
from nltk.tokenize import word_tokenize
from Comments import Comment

def classify():
    train = [("customer", "customer"),
                     ("account", "account"),
                     ("login", "login"),
                     ("payment", "payment"),
                     ("website", "website"),
                     ("competitor", "competitor"),
                     ("navigation navigate", "navigation"),
                     ("unkonwn", "unkonwn"),
                     ]

    # Step 2
    dictionary = set(word.lower() for passage in train for word in word_tokenize(passage[0]))

    # Step 3
    t = [({word: (word in word_tokenize(x[0])) for word in dictionary}, x[1]) for x in train]

    comments = []
    classifier = nltk.NaiveBayesClassifier.train(t)


    workbook = open_workbook("C:\\Users\\pgssolcenter\\Desktop\\voc.xlsx")
    sheets = workbook.sheet_names()


    categaroy_list = ["website","login","customer","navigation","account"]


    required_data = []
    for sheet_name in sheets:
        sh = workbook.sheet_by_name(sheet_name)
        for rownum in range(sh.nrows):
            if rownum == 0:
                continue
            row_valaues = sh.row_values(rownum)
            for row_number in [6,7,8]:
                comment = Comment("", [], "")
                test_data = row_valaues[row_number]
                if test_data != '':
                    test_data_features = {word.lower(): (word in word_tokenize(test_data.lower())) for word in dictionary}
                    categarory = classifier.classify(test_data_features)
                    comment.comment = test_data
                    # print test_data

                    if categarory not in categaroy_list:
                        comment.categories = ["uncategarized"]
                    else :
                        if categarory == "website" :
                            # print (test_data_features)
                            # print (classifier.classify(test_data_features))
                            comment.categories = ["website"]

                        if categarory == "login":
                            # print (test_data_features)
                            # print (classifier.classify(test_data_features))
                            comment.categories = ["login"]

                        if categarory == "customer" :
                            # print (test_data_features)
                            # print (classifier.classify(test_data_features))
                            comment.categories = ["customer"]

                        if categarory== "navigation":
                            # print (test_data_features)
                            # print (classifier.classify(test_data_features))
                            comment.categories = ["navigation"]


                        if categarory == "account":
                            #print (test_data_features)
                            #print (classifier.classify(test_data_features))
                            comment.categories = ["account"]
                    comments.append(comment)

    return comments



